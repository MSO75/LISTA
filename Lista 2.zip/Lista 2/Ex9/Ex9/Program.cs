﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double p;
            string s;
            double R;

            Console.Write("Informar o sexo F ou M");
            s = Console.ReadLine();

            Console.Write("Digitar a altura");
            a = Double.Parse(Console.ReadLine());

            Console.Write("Digitar o peso");
            p = Double.Parse(Console.ReadLine());

            R = p / (a * a);

            if (s == "M")
                if (R < 20)
                    Console.WriteLine("Abaixo do peso.");
                else
                if (R >= 25)
                    Console.WriteLine("Acima do peso.");
                else
                    Console.WriteLine("Peso ideal.");
            else
            if (R < 19)
                Console.WriteLine("Abaixo do peso.");
            else
            if (R >= 24)
                Console.WriteLine("Acima do peso,");
            else
                Console.WriteLine("Peso ideal.");
        }
    }
}
