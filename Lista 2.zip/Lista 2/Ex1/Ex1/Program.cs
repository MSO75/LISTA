﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.WriteLine("Digitar  1° valor");
            a = double.Parse(Console.ReadLine());

            Console.WriteLine("Digitar  2° valor");
            b = double.Parse(Console.ReadLine());

            if (a > b)
            {
                Console.WriteLine(" 1° valor é maior");

                Console.WriteLine("");
            }
            else
            Console.WriteLine(" 2° valor é maior");

            Console.WriteLine("");
        }
    }
}
