﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;

            Console.Write(" Digitar o 1º Valor:");
            a = int.Parse(Console.ReadLine());

            Console.Write("Digitar o 2º Valor:");
            b = int.Parse(Console.ReadLine());

            if (a == b)
            {
                Console.Write("valores iguais");
                Console.WriteLine("");
            }
            else
              if (a > b)
            {
                Console.Write(" 1º é o maior");
                Console.WriteLine("");
            }
            else
            {
                Console.Write(" 2º é o maior");
                Console.WriteLine("");
            }+
        }
    }
}
