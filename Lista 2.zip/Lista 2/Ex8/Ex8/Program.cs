﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double A;
            double B;
            double C;

            Console.Write("Digitar o primeiro valor: ");
            A = int.Parse(Console.ReadLine());

            Console.Write("Digitar o segundo valor: ");
            B = int.Parse(Console.ReadLine());

            Console.Write("Digitar o terceiro valor: ");
            C = int.Parse(Console.ReadLine());

            if (((B * B) + (C * C)) == (A * A))
                Console.WriteLine(" Triângulo Retângulo");
            else
                Console.WriteLine("Não é  Triângulo Retângulo");
        }
    }
}
