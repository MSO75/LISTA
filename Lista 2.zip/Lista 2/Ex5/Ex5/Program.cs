﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double h;
            double a;

            Console.WriteLine("Digitar o valor da base do triângulo");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine("Digitar o valor da altura do triângulo");
            h = double.Parse(Console.ReadLine());

            a = b * h;

            Console.WriteLine("A área do triângulo é {0} metros.", a);

            if (a > 100)
                Console.WriteLine("Terreno grande.");
            else
                Console.WriteLine("Terreno pequeno.");


        }
    }
}
