﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p;
            double h;
            double r;
            double a2;

            Console.WriteLine("Digitar o peso");
            p = double.Parse(Console.ReadLine());

            Console.WriteLine("Digitar a altura");
            h = double.Parse(Console.ReadLine());

            a2 = h * h;
            r = p / a2;

            if (r < 20)
                Console.WriteLine("Abaixo do peso");
            else
                if (r >= 25)
                Console.WriteLine("Acima do peso");
            else
                if (r < 25)
                Console.WriteLine("Peso ideal");
        }
    }
}
